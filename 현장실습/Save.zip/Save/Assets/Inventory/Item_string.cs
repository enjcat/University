﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Item_string : MonoBehaviour
{
    public String code = null;
}
